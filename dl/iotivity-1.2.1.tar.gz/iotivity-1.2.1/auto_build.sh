#! /bin/bash
python auto_build.py "$@"
