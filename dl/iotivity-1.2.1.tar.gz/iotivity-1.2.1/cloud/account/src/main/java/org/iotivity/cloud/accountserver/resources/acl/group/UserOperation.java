package org.iotivity.cloud.accountserver.resources.acl.group;

public enum UserOperation {
    ADD, REPLACE, DELETE
}
